from DatasetManager import DatasetManager

dm = DatasetManager()

dm.createDataset()
