#Created by Theo Guidoux on 22/09/2018

class Vigenere():
	"""Tools for Vigenere."""
	def __init__(self):
		pass

	def getTable(self):
		table = {
		"A" : "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
		"B" : "BCDEFGHIJKLMNOPQRSTUVWXYZB",
		"C" : "CDEFGHIJKLMNOPQRSTUVWXYZAB",
		"D" : "DEFGHIJKLMNOPQRSTUVWXYZABC",
		"E" : "EFGHIJKLMNOPQRSTUVWXYZABCD",
		"F" : "FGHIJKLMNOPQRSTUVWXYZABCDE",
		"G" : "GHIJKLMNOPQRSTUVWXYZABCDEF",
		"H" : "HIJKLMNOPQRSTUVWXYZABCDEFG",
		"I" : "IJKLMNOPQRSTUVWXYZABCDEFGH",
		"J" : "JKLMNOPQRSTUVWXYZABCDEFGHI",
		"K" : "KLMNOPQRSTUVWXYZABCDEFGHIJ",
		"L" : "LMNOPQRSTUVWXYZABCDEFGHIJK",
		"M" : "MNOPQRSTUVWXYZABCDEFGHIJKL",
		"N" : "NOPQRSTUVWXYZABCDEFGHIJKLM",
		"O" : "OPQRSTUVWXYZABCDEFGHIJKLMN",
		"P" : "PQRSTUVWXYZABCDEFGHIJKLMNO",
		"Q" : "QRSTUVWXYZABCDEFGHIJKLMNOP",
		"R" : "RSTUVWXYZABCDEFGHIJKLMNOPQ",
		"S" : "STUVWXYZABCDEFGHIJKLMNOPQR",
		"T" : "TUVWXYZABCDEFGHIJKLMNOPQRS",
		"U" : "UVWXYZABCDEFGHIJKLMNOPQRST",
		"V" : "VWXYZABCDEFGHIJKLMNOPQRSTU",
		"W" : "WXYZABCDEFGHIJKLMNOPQRSTUV",
		"X" : "XYZABCDEFGHIJKLMNOPQRSTUVW",
		"Y" : "YZABCDEFGHIJKLMNOPQRSTUVWX",
		"Z" : "ZABCDEFGHIJKLMNOPQRSTUVWXY",
		}
		return table


	def encrypt(self, plaintext, key):
		abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		plaintext = plaintext.replace(" ", "")
		plainkey = ""
		while len(plainkey) < len(plaintext):
			plainkey = plainkey + key

		table = self.getTable()
		output = ""
		for i in range(0, len(plaintext)):
			output = output + table[plaintext[i]][abc.index(plainkey[i])]
		return output

	def decrypt(self, ciphertext, key):
		abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		ciphertext = ciphertext.replace(" ", "")
		plainkey = ""
		while len(plainkey) < len(ciphertext):
			plainkey = plainkey + key

		table = self.getTable()
		output = ""

		for i in range(0, len(ciphertext)):
			output = output + abc[table[plainkey[i]].index(ciphertext[i])]
		return output

	def code_vigenere(self, message, cle, decode = False):
		print(message)
		message_code = ""
		for i,c in enumerate(message):
			d = cle[ i % len(cle) ]
			d = ord(d) - 65
			if decode: d = 26 - d
			message_code += chr((ord(c)-65+d)%26+65)
		return message_code
